'use strict';

let express = require('express');
let bodyParser = require('body-parser');
let routerArticulos = require('./routes/articulos');
let routerUsuarios = require('./routes/users');

let application = express();
application.use(bodyParser.json()); 
application.use(routerArticulos);
application.use(routerUsuarios);

module.exports = application;