'use strict';
 
let mongoose = require('mongoose');
let application = require('./application');
 
mongoose.connect('mongodb://localhost:27017/tiendaweb').then(
    () => {
        console.log('Conexion exitosa a DB tiendaweb');
        application.listen(1742);
    },
    err => {
        console.error(err);
    }
);