'use strict';

let jwt = require('jwt-simple');
let moment = require('moment');

let secret = 'asdayiuttyi34578.,,qw';

function createToken(usuario) {
    let payload = {
        sub: usuario._id,
        username: usuario.username,
        rol: usuario.rol,
        iat: moment().unix(),
        exp: moment().add(30, 'minutes').unix()
    };
    return jwt.encode(payload, secret);
}

function validateToken(req, res, next) {
    try {
        if (!req.headers.authorization) {
            return res.status(403).send({ message: 'No cuenta con autorizacion' });
        }
        let token = req.headers.authorization.replace('Bearer ', '');
        let payload = jwt.decode(token, secret);
        req.header.userId = payload.sub; 
        req.usuarioRol = payload.rol; 
        next();
    }
    catch (ex) {
        res.status(401).send({ message: 'Token inválido' });
    }
}

module.exports = { createToken, validateToken };