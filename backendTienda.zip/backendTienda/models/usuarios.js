'use strict';

let mongoose = require('mongoose');

let Schema = mongoose.Schema;

let UsuarioSchema = Schema(
    {
        username: { type: String, unique: true, required: true },
        password: { type: String, required: true },
        rol: { type: String, enum: ['administrador', 'estandar'], required: true }
    }
);

module.exports = mongoose.model('usuarios', UsuarioSchema); 