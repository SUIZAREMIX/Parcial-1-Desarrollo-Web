'use strict';

let mongoose = require('mongoose');

let Schema = mongoose.Schema;

let ArticuloSchema = Schema(
    {
        Titulo: String,
        Descripcion: String,
        Precio: Number
    }
);

module.exports = mongoose.model('articulos', ArticuloSchema);
