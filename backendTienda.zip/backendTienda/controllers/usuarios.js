'use strict';

let Usuario = require('../models/usuarios');
let auth = require('../helpers/auth');
let bcrypt = require('bcryptjs');

function registrar(req, res) {
    let username = req.body.username;
    let password = req.body.password;
    let rol = req.body.rol;
    if (!username || !password || !rol) {
        return res.status(400).send({ message: 'Debe enviar username, password y rol' });
    }
    if (rol !== 'administrador' && rol !== 'estandar') {
        return res.status(400).send({ message: 'El rol debe ser administrador o estandar' });
    }
    let usuario = new Usuario({
        username: username,
        password: bcrypt.hashSync(password, 10),
        rol: rol
    });
    usuario.save().then(
        (usuario) => {
            res.status(200).send({ usuario: usuario });
        }
    ).catch(
        (err) => {
            res.status(500).send({ message: 'Error al registrar el usuario' });
        }
    );
}

function login(req, res) {
    let usernameParametro = req.body.username;
    let passwordParametro = req.body.password;
    if (!usernameParametro || !passwordParametro) {
        return res.status(400).send({ message: 'Debe enviar username y password' });
    }
    Usuario.findOne({ username: usernameParametro }).then(
        (usuario) => {
            if (!usuario) {
                return res.status(404).send({ message: 'No existe el usuario' });
            }
            if (!bcrypt.compareSync(passwordParametro, usuario.password)) {
                return res.status(401).send({ message: 'Contraseña incorrecta' });
            }
            res.status(200).send({ token: auth.createToken(usuario) });
        }
    ).catch(
        (err) => {
            res.status(500).send({ message: 'Error al realizar el login' });
        }
    );
}

module.exports = { registrar, login };