'use strict';

let Articulo = require('../models/articulos');

function crearArticulo(req, resp) {
    // solo los administradores puedan crear articulos
    if (req.usuarioRol !== 'administrador') {
        return resp.status(403).send({ 'message': 'No autorizado. Solo los administradores pueden crear artículos.' });
    }

    let requestBody = req.body;

    if (!requestBody) {
        return resp.status(400).send({ 'message': 'no body was sent' });
    }
    else if (!requestBody.Titulo || !requestBody.Precio) {
        return resp.status(400).send({ 'message': 'missing mandatory fields' });
    }
    else if (requestBody.Titulo.trim() === '' || requestBody.Precio <= 0) {
        return resp.status(400).send({ 'message': 'invalid values in mandatory fields' });
    }
    else {
        let nuevoArticulo = new Articulo();
        nuevoArticulo.Titulo = requestBody.Titulo;
        nuevoArticulo.Descripcion = requestBody.Descripcion;
        nuevoArticulo.Precio = requestBody.Precio;

        nuevoArticulo.save().then(
            (articuloCreado) => {
                resp.status(201).send({ 'message': 'articulo created', 'articulo': articuloCreado });
            },
            err => {
                resp.status(500).send({ 'message': 'internal error', 'error': err })
            }
        );
    }
}

function consultarArticulos(req, resp) {
    
    Articulo.find().then(
        (articulos) => {
            resp.status(200).send(articulos);
        },
        err => {
            resp.status(500).send({ 'message': 'internal error', 'error': err })
        }
    );
}

module.exports = { crearArticulo, consultarArticulos };
